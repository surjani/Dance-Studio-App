package com.capg.dance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DanceStudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
