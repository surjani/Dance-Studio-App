package com.capg.dance.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.dance.bean.Booking;
import com.capg.dance.service.ChoreographerServiceImpl;

@RestController // declaring class as controller class
public class ChoreographerController {

	@Autowired
	ChoreographerServiceImpl cservice;

	// for choreographer login
	@RequestMapping(method = RequestMethod.GET, value = "/chLogin/{userId}/{password}/{roleId}")
	public String login(@PathVariable int userId, @PathVariable String password, @PathVariable int roleId) {
		return cservice.chLogin(userId, password, roleId);
	}

	// for changing password
	@RequestMapping(method = RequestMethod.POST, value = "/changePassword/{userId}/{password}/{newpass}/{roleId}")
	public String changePassword(@PathVariable int userId, @PathVariable String password, @PathVariable String newpass,
			@PathVariable int roleId) {
		return cservice.changePassword(userId, password, newpass, roleId);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/viewBooking/{userId}")
	public Optional<Booking> viewBooking(@PathVariable int userId) {
		return cservice.viewBooking(userId);
	}

}
