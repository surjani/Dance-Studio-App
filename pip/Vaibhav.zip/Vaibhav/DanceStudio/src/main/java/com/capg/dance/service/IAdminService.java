package com.capg.dance.service;

import com.capg.dance.bean.Dance;
import com.capg.dance.bean.User;

//interface for Admin service
public interface IAdminService {

	// to add new choreographer
	public User addChoreographer(User user);

	// to add new Admin
	public User addAdmin(User user);

	// to login Admin
	public String loginAdmin(int userId, String password, int roleId);

}
