package com.capg.dance.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // specifies that class is an entity class
@Table(name = "Dance") // creates table with name booking in database
public class Dance {
	
	@Id // makes field as primary key
	private int danceId;
	private String danceName;
	private double danceAmount;
	private String dancePeriod;
	private String danceService;
	private int userId;
	
	
	//getter setter
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getDanceId() {
		return danceId;
	}
	public void setDanceId(int danceId) {
		this.danceId = danceId;
	}
	public String getDanceName() {
		return danceName;
	}
	public void setDanceName(String danceName) {
		this.danceName = danceName;
	}
	public double getDanceAmount() {
		return danceAmount;
	}
	public void setDanceAmount(double danceAmount) {
		this.danceAmount = danceAmount;
	}
	public String getDancePeriod() {
		return dancePeriod;
	}
	public void setDancePeriod(String dancePeriod) {
		this.dancePeriod = dancePeriod;
	}
	public String getDanceService() {
		return danceService;
	}
	public void setDanceService(String danceService) {
		this.danceService = danceService;
	}
	@Override
	public String toString() {
		return "Dance [danceId=" + danceId + ", danceName=" + danceName + ", danceAmount=" + danceAmount
				+ ", dancePeriod=" + dancePeriod + ", danceService=" + danceService + ", userId=" + userId + "]";
	}
	public Dance() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
