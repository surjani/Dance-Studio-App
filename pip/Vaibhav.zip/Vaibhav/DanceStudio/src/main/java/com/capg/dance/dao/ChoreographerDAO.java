package com.capg.dance.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.dance.bean.User;

public interface ChoreographerDAO extends JpaRepository<User, Integer>{

}
