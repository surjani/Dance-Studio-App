package com.capg.dance.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // specifies that class is an entity class
@Table(name = "Booking") // creates table with name booking in database
public class Booking {

	private int bookingId;
	@Id // make field as primary key
	private int userId;
	private Date bookingDate;
	private int danceId;
	private String danceName;
	private double danceAmount;
	private String dancePeriod;
	private String danceService;

	// Getter And Setter
	public int getBookingId() {
		return bookingId;
	}

	public String getDanceName() {
		return danceName;
	}

	public void setDanceName(String danceName) {
		this.danceName = danceName;
	}

	public double getDanceAmount() {
		return danceAmount;
	}

	public void setDanceAmount(double danceAmount) {
		this.danceAmount = danceAmount;
	}

	public String getDancePeriod() {
		return dancePeriod;
	}

	public void setDancePeriod(String dancePeriod) {
		this.dancePeriod = dancePeriod;
	}

	public String getDanceService() {
		return danceService;
	}

	public void setDanceService(String danceService) {
		this.danceService = danceService;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public int getDanceId() {
		return danceId;
	}

	public void setDanceId(int danceId) {
		this.danceId = danceId;
	}

	// hashcode and equals
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookingDate == null) ? 0 : bookingDate.hashCode());
		result = prime * result + bookingId;
		result = prime * result + danceId;
		result = prime * result + userId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (bookingDate == null) {
			if (other.bookingDate != null)
				return false;
		} else if (!bookingDate.equals(other.bookingDate))
			return false;
		if (bookingId != other.bookingId)
			return false;
		if (danceId != other.danceId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	
	

	// constructor using fields
	public Booking(int bookingId, int userId, Date bookingDate, int danceId) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.bookingDate = bookingDate;
		this.danceId = danceId;
	}

	// toString
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId + ", bookingDate=" + bookingDate + ", danceId="
				+ danceId + ", danceName=" + danceName + ", danceAmount=" + danceAmount + ", dancePeriod=" + dancePeriod
				+ ", danceService=" + danceService + "]";
	}

	// constructor from superclass
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

}
