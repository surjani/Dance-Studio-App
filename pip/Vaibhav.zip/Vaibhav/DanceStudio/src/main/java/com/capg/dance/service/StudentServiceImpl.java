package com.capg.dance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dance.bean.User;
import com.capg.dance.dao.StudentDAO;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	StudentDAO stdao;

	User u;

	@Override
	public User register(User user) {
		// TODO Auto-generated method stub
		if (user.getRoleId() == 2) {
			String pass = user.getPassword();

			// Encrypting password
			StringBuffer sb = new StringBuffer();
			char ch[] = pass.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();
			user.setPassword(result);
			return stdao.save(user);
		}
		return null;
	}
}
