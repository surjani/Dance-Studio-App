package com.capg.dance.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.dance.bean.Booking;

public interface BookingDAO extends JpaRepository<Booking, Integer>{

}
