package com.capg.dance.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.dance.bean.Dance;
import com.capg.dance.bean.User;

public interface AdminDAO extends JpaRepository<User, Integer> {

}
