package com.capg.dance.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dance.bean.Booking;
import com.capg.dance.bean.User;
import com.capg.dance.dao.BookingDAO;
import com.capg.dance.dao.ChoreographerDAO;

@Service
public class ChoreographerServiceImpl implements IChoreographerService {

	@Autowired
	ChoreographerDAO cdao;

	@Autowired
	BookingDAO bdao;

	User u;
	Booking book;

	// for choreographer login
	@Override
	public String chLogin(int userId, String password, int roleId) {
		// TODO Auto-generated method stub
		u = cdao.findById(userId).get();

		if ((u.getRoleId() == 3)) {
			StringBuffer sb = new StringBuffer();
			char ch[] = password.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();

			if (u.getPassword().equals(result)) {
				return "Login Successful";
			}
		}
		return "Login Failed";
	}

	// for changing password
	@Override
	public String changePassword(int userId, String password, String newpass, int roleId) {
		// TODO Auto-generated method stub

		u = cdao.findById(userId).get();

		if ((u.getRoleId() == 3)) {
			StringBuffer sb = new StringBuffer();
			char ch[] = password.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();

			if (u.getPassword().equals(result)) {
				StringBuffer sb1 = new StringBuffer();
				char ch1[] = newpass.toCharArray();
				for (int i = 0; i < ch1.length; i++) {
					String hexString = Integer.toHexString(ch1[i]);
					sb1.append(hexString);
				}
				String result1 = sb1.toString();
				u.setPassword(result1);
				cdao.save(u);
				return "Password Updated successfully";
			}
		}
		return null;

	}

	@Override
	public Optional<Booking> viewBooking(int userId) {
		// TODO Auto-generated method stub
		book = bdao.findById(userId).get();
		if(bdao.findById(userId)!=null) {
			return bdao.findById(userId);
		}
		return null;
	}
}
