package com.capg.dance.service;

import com.capg.dance.bean.User;

public interface IStudentService {
	
	public User register(User user);
	

}
