package com.capg.dance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.dance.bean.Dance;
import com.capg.dance.bean.User;
import com.capg.dance.service.AdminServiceImpl;

@RestController // declaring class as controller class
public class AdminController {

	@Autowired
	AdminServiceImpl adminService;

	// for adding choreographer in database
	@RequestMapping(method = RequestMethod.POST, value = "/addChoreographer")
	public User addChoreographer(@RequestBody User user) {
		return adminService.addChoreographer(user);
	}

	// for adding new admin
	@RequestMapping(method = RequestMethod.POST, value = "/addAdmin")
	public User addAdmin(@RequestBody User user) {
		return adminService.addAdmin(user);
	}

	// for admin login
	@RequestMapping(method = RequestMethod.GET, value = "/loginAdmin/{userId}/{password}/{roleId}")
	public String login(@PathVariable int userId, @PathVariable String password, @PathVariable int roleId) {
		return adminService.loginAdmin(userId, password, roleId);
	}

}
