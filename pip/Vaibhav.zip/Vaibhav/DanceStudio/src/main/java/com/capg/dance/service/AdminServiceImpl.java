package com.capg.dance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dance.bean.Dance;
import com.capg.dance.bean.User;
import com.capg.dance.dao.AdminDAO;
import com.capg.dance.dao.DanceDAO;

@Service // denotes that annotated class contains business logic
public class AdminServiceImpl implements IAdminService {

	@Autowired // provides dependency injection
	AdminDAO adao;

	@Autowired
	DanceDAO ddao;

	User u;
	Dance d;

	// add new choreographer after encrypting password
	@Override
	public User addChoreographer(User user) {
		if (user.getRoleId() == 3) {
			String pass = user.getPassword();

			// Encrypting password
			StringBuffer sb = new StringBuffer();
			char ch[] = pass.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();
			user.setPassword(result);
			return adao.save(user);
			
		}
		return null;
	}

	// register new admin
	public User addAdmin(User user) {
		if (user.getRoleId() == 1) {
			String pass = user.getPassword();

			// Encrypting password
			StringBuffer sb = new StringBuffer();
			char ch[] = pass.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();
			user.setPassword(result);
			return adao.save(user);
		}
		return null;
	}

	// login admin
	public String loginAdmin(int userId, String password, int roleId) {
		u = adao.findById(userId).get();
		if (u.getRoleId()==1) {
			StringBuffer sb = new StringBuffer();
			char ch[] = password.toCharArray();
			for (int i = 0; i < ch.length; i++) {
				String hexString = Integer.toHexString(ch[i]);
				sb.append(hexString);
			}
			String result = sb.toString();

			if (u.getPassword().equals(result)) {
				return "Login Successful";
			}
		}
		return "Login Failed";
	}

}
