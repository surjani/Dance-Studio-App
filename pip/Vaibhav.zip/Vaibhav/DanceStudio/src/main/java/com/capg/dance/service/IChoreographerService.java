package com.capg.dance.service;

import java.util.Optional;

import com.capg.dance.bean.Booking;

//interface for choreographer service
public interface IChoreographerService {
	
	//for choreographer login
	public String chLogin(int userId, String password, int roleId);
	
	//for password change
	public String changePassword(int userId, String password, String newpass, int roleId);
	
	public Optional<Booking> viewBooking(int userId);

}
